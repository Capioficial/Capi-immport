let handler = async (m, { conn, usedPrefix, isOwner }) => {
let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:Capi;;\nFN:Capi\nORG:capi\nTITLE:\nitem1.TEL;waid=5218261275256:5218261275256\nitem1.X-ABLabel:capi\nX-WA-BIZ-DESCRIPTION:\nX-WA-BIZ-NAME Zorlox\nEND:VCARD`
await conn.sendMessage(m.chat, { contacts: { displayName: 'Capi', contacts: [{ vcard }] }}, {quoted: m})
}
handler.help = ['owner']
handler.tags = ['main']
handler.command = ['owner', 'creator', 'creador', 'Capi'] 

export default handler